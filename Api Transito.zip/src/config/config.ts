export default {
    jwtSecret:'BDPEK@'
}