
export default {

  
   /* database: {
        host: 'localhost',
        user: 'transito',
        password: 'transito123',
        database: 'mancomunidad',
        multipleStatements: true
    }   */
    database: {
        host: 'localhost',
        user: 'root',
        password: '',
        database: 'mancomunidad',
    } 
  
}