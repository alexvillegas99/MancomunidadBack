# Api
1 terminal .- tsc -w
2 terminal .- npm run dev
3 terminal .- node app
